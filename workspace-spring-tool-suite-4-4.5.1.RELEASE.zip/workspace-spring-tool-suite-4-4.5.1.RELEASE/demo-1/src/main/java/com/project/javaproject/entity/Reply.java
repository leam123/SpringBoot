package com.project.javaproject.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Reply {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String title;
	private String body;
	private int repliedBy;
	private Date dateReplied;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public int getRepliedBy() {
		return repliedBy;
	}
	public void setRepliedBy(int repliedBy) {
		this.repliedBy = repliedBy;
	}
	public Date getDateReplied() {
		return dateReplied;
	}
	public void setDateReplied(Date dateReplied) {
		this.dateReplied = dateReplied;
	}


}
