package com.project.javaproject.entity;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Answer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String body;
	private int votes;
	private int answeredBy;
	private Date dateAccepted;
	private Date dateAnswered;

	@OneToMany(cascade = CascadeType.ALL, targetEntity = Reply.class)
	@JoinColumn(name = "ansId", referencedColumnName = "id")
	private List<Reply> replies;


	public List<Reply> getReplies() {
		return replies;
	}
	public void setReplies(List<Reply> replies) {
		this.replies = replies;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public int getVotes() {
		return votes;
	}
	public void setVotes(int votes) {
		this.votes = votes;
	}
	public int getAnsweredBy() {
		return answeredBy;
	}
	public void setAnsweredBy(int answeredBy) {
		this.answeredBy = answeredBy;
	}
	public Date getDateAccepted() {
		return dateAccepted;
	}
	public void setDateAccepted(Date dateAccepted) {
		this.dateAccepted = dateAccepted;
	}
	public Date getDateAnswered() {
		return dateAnswered;
	}
	public void setDateAnswered(Date dateAnswered) {
		this.dateAnswered = dateAnswered;
	}


}
