package com.project.javaproject.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.project.javaproject.entity.Account;

public interface AccountRepository extends JpaRepository<Account,Integer>{
	
	@Query(value = "SELECT * FROM account INNER JOIN faculty ON account.id=faculty.id", nativeQuery = true)
	public List<Account> getAccFaculty();
	
	//Account findByUsername(String username);
}
