package com.project.javaproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;

import com.project.javaproject.entity.Account;
import com.project.javaproject.repository.AccountRepository;

@Controller
public class GarciaController {
	@Autowired
	AccountRepository ar;
	
	@RequestMapping("/login")
	public String welcome() {
		return "login.jsp";
	}
	
	@PostMapping("/homepage")
	public String newAccount(Account account) {
		return "homepage.jsp";
	}
	
	@GetMapping("/all_accounts")
	public List<Account> getAll(){
		return ar.findAll();
	}
}
