package com.example.demo;

import java.util.Date;

public class Post {
	private Date date_posted;
	private String title;
	private String body;
	private String posted_by;
	private int votes;
	
	public Post(Date date_posted, String title, String body, String posted_by, int votes) {
		super();
		this.date_posted = new Date();
		this.title = title;
		this.body = body;
		this.posted_by = posted_by;
		this.votes = votes;
	}
	
	public Post(String body) {
		super();
		this.body = body;
	}
	
	public Date getDate_posted() {
		return date_posted;
	}
	public void setDate_posted(Date date_posted) {
		this.date_posted = date_posted;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getPosted_by() {
		return posted_by;
	}
	public void setPosted_by(String posted_by) {
		this.posted_by = posted_by;
	}
	public int getVotes() {
		return votes;
	}
	public void setVotes(int votes) {
		this.votes = votes;
	}
}
