package com.example.demo;

//import java.util.List;

//import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface PostRepo extends CrudRepository<Post,String>{
	
	//List<Post> findByBody(String body);
	
	//@Query("from Post where title=?1 order by title")
	//List<Post> findByTitleSorted(String title);
}
