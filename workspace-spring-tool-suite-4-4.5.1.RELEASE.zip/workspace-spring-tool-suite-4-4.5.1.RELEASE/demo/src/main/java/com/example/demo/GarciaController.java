package com.example.demo;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class GarciaController {
	
	@RequestMapping(value= "/ask", method=RequestMethod.GET)
	public String ask() {		
		System.out.println("hey");
		return "Ask.jsp";
	} 
	
	@Autowired
	PostRepo pr;
	
	@RequestMapping(value= "addPost",method = RequestMethod.GET)
	public ModelAndView addPost(Post post){
		//pr.save(post);
		ModelAndView mv = new ModelAndView("Ask.jsp");
		mv.addObject("body",post);
		return mv;
	}
	
	@RequestMapping(value= "getPost",method = RequestMethod.GET)
	public ModelAndView getPost() {
		List<Post> post = new ArrayList<Post>();
		ModelAndView mv = new ModelAndView("Ask.jsp");
		mv.addObject(post);
		return mv;
	}
}

