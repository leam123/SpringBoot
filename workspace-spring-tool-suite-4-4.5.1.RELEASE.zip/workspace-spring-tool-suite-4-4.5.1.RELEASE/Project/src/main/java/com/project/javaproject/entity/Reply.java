package com.project.javaproject.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Reply {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String title;
	private String body;
	private int repliedBy;
	private Date dateReplied;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ansId")
	private Answer answer;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "accId")
	private Account account;
	
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public Answer getAnswer() {
		return answer;
	}
	public void setAnswer(Answer answer) {
		this.answer = answer;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public int getRepliedBy() {
		return repliedBy;
	}
	public void setRepliedBy(int repliedBy) {
		this.repliedBy = repliedBy;
	}
	public Date getDateReplied() {
		return dateReplied;
	}
	public void setDateReplied(Date dateReplied) {
		this.dateReplied = dateReplied;
	}


}
