package com.project.javaproject.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.project.javaproject.entity.Account;
import com.project.javaproject.entity.Answer;
import com.project.javaproject.entity.Department;
import com.project.javaproject.entity.Post;
import com.project.javaproject.model.ChatMessage;
import com.project.javaproject.repository.AnswerRepository;
import com.project.javaproject.repository.PostRepository;

@Controller
public class AxintoController {

	@Autowired
	private PostRepository postRepo;
	@Autowired
	private AnswerRepository ansRepo;
	
	@RequestMapping("/post/viewall")
	public String indexView(ModelMap mm) {
		List<Post> posts=postRepo.findAll();
		mm.addAttribute("posts",posts);
		return "/viewPosts.jsp";
	}
	
	@RequestMapping("/post")
	public String viewPost(int id,ModelMap mm) {
		mm.addAttribute("post",postRepo.getOne(id));
		return "/post.jsp";
	}
	
	@RequestMapping("/post/answer/submit")
	public String submitAnswer(ModelMap mm, int postId, String body, HttpSession session) {
		Post post=postRepo.getOne(postId);
		Account account=(Account)session.getAttribute("user");
		mm.addAttribute("post",post);
		Answer answer=new Answer();
		answer.setBody(body);
		answer.setPost(post);
		answer.setAccount(account);
		ansRepo.save(answer);
		return "/post.jsp";
	}
	
	@MessageMapping("/chat.register")
	@SendTo("/topic/public")
	public ChatMessage register(@Payload ChatMessage chatMessage, SimpMessageHeaderAccessor headerAccessor) {
		headerAccessor.getSessionAttributes().put("username", chatMessage.getSender());
		return chatMessage;
	}

	@MessageMapping("/chat.send")
	@SendTo("/topic/public")
	public ChatMessage sendMessage(@Payload ChatMessage chatMessage) {
		return chatMessage;
	}

	
	@RequestMapping("/chat/start")
	public String startChat() {
		return "/chat.jsp";
	}
	
	@RequestMapping("/ask")
	public String askView() {
		return "/ask.jsp";
	}
	
	@RequestMapping("/ask/submit")
	public String askSubmit(Post post,int dep_id,HttpSession session, ModelMap mm) {
		Account user=(Account)session.getAttribute("user");
		post.setAccount(user);
		Department dep=new Department();
		dep.setId(dep_id);
		post.setDepartment(dep);
		postRepo.save(post);
		List<Post> posts=postRepo.findAll();
		mm.addAttribute("posts",posts);
		return "/homepage.jsp";
	}
}
