package com.project.javaproject.repository;

//import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.project.javaproject.entity.Post;

public interface PostRepository extends JpaRepository<Post,Integer>{
	
	@Query(value="SELECT * FROM post ORDER BY votes DESC", nativeQuery=true)
	public List<Post> getAllPostsByVotes();
	
	@Query(value="SELECT * FROM post ORDER BY date_uploaded ASC", nativeQuery=true)
	public List<Post> getAllPostsByOldest();
	
	@Query(value="SELECT * FROM post ORDER BY date_uploaded DESC", nativeQuery=true)
	public List<Post> getAllPostsByNewest();
	
	@Query(value="SELECT * FROM post WHERE dep_id=?1",nativeQuery = true)
	public List<Post> getAllPostsByDepartment(int dep);
	
}
