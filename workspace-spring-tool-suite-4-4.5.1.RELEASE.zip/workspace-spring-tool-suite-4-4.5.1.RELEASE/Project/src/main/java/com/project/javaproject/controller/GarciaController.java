/**
 * Author: Garcia, Leamor T.
 * Date: February 2020
 * 
 * Project Desc: A simple web application where the user can post questions and other users can answer and reply to it.
 * 
 * A controller for managing and retrieving data from database. Displaying those data from the database in the homepage, 
 * logging in, managing of account by the admin.
 * 
 * **/

package com.project.javaproject.controller;

//import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.project.javaproject.entity.Account;
import com.project.javaproject.entity.Department;
import com.project.javaproject.entity.Post;
import com.project.javaproject.repository.AccountRepository;
import com.project.javaproject.repository.DepartmentRepository;
import com.project.javaproject.repository.PostRepository;

@Controller
public class GarciaController {
	@Autowired
	private AccountRepository accountrepo;
	@Autowired
	private PostRepository postrepo;
	@Autowired
	private DepartmentRepository deptrepo;	
	
	//This is for the login method. 
	@RequestMapping("/login")
	public String login(String username, String password) {
		return "/login.jsp";
	}
	
	//If the username and password is present in the database this page will display.
	@RequestMapping("/homepage")
	public String loginValidate(String username, String password, ModelMap mm, HttpSession session) {
		Account acc=accountrepo.login(username, password);
		if(acc==null)
			return "/login.jsp";
		
		//check if the type of account is an admin
		else if(acc.getTypeString().equals("admin")) {
			return "/menu.jsp";
		}
		else {
			List<Post> posts=postrepo.findAll();
			mm.addAttribute("posts",posts);
			session.setAttribute("user", acc);
			mm.addAttribute("user",acc);
			return "/homepage.jsp";
		}
	}
	
	//if the account is an admin
	@RequestMapping("/admin_menu")
	public String menu() {
		return "/menu.jsp";
	}
	
	@RequestMapping("/register/account")
	public String register() {
		return "/Register.jsp";
	}
	
	@RequestMapping("/register/save")
	public String registerSave(Account account) {
		accountrepo.save(account);
		return "/Register.jsp";
	}
	
	@RequestMapping("/register/department")
	public String registerDept() {
		return "/addDept.jsp";
	}
	
	@RequestMapping("/department/save")
	public String deptSave(Department dept) {
		deptrepo.save(dept);
		return "/addDept.jsp";
	}
	
	/*@RequestMapping("/delete_account")
	public String delete() {
		return "/delete.jsp";
	}
	
	@GetMapping("/delete/account")
	public String deleteAccount(int id) {
		
		return null;
	}*/
	
	//displaying all post of the users after logging in
	@GetMapping("/homepage/all_post")
	public String getAllPosts(ModelMap mm){
		List<Post> posts=postrepo.findAll();
		mm.addAttribute("posts",posts);
		return "/homepage.jsp";
	}
	
	//sorting all post by the users according to dates
	@GetMapping("/homepage/newest_post")	
	public String getAllPostsByNewest(ModelMap mm) {
		List<Post> posts = postrepo.getAllPostsByNewest();
		mm.addAttribute("posts", posts);
		return "/homepage.jsp";
	}
	
	@GetMapping("/homepage/oldest_post")	
	public String getAllPostsByOldest(ModelMap mm) {
		List<Post> posts = postrepo.getAllPostsByOldest();
		mm.addAttribute("posts", posts);
		return "/homepage.jsp";
	}
	
	@GetMapping("/homepage/popular")	
	public String getAllPostsByVotes(ModelMap mm) {
		List<Post> posts = postrepo.getAllPostsByVotes();
		mm.addAttribute("posts", posts);
		return "/homepage.jsp";
	}
	
	//getting posts according by the department
	@GetMapping("/homepage/civil")
	public String getAllCivil(ModelMap mm,int dep){
		List<Post> posts=postrepo.getAllPostsByDepartment(dep);
		mm.addAttribute("posts",posts);
		return "/homepage.jsp";
	}
	
	@GetMapping("/homepage/mechanical")
	public String getAllMechanical(ModelMap mm,int dep){
		List<Post> posts=postrepo.getAllPostsByDepartment(dep);
		mm.addAttribute("posts",posts);
		return "/homepage.jsp";
	}
	
	@GetMapping("/homepage/mining")
	public String getAllMining(ModelMap mm,int dep){
		List<Post> posts=postrepo.getAllPostsByDepartment(dep);
		mm.addAttribute("posts",posts);
		return "/homepage.jsp";
	}
	
	@GetMapping("/homepage/electrical")
	public String getAllElectrical(ModelMap mm,int dep){
		List<Post> posts=postrepo.getAllPostsByDepartment(dep);
		mm.addAttribute("posts",posts);
		return "/homepage.jsp";
	}
	
	@GetMapping("/homepage/electronics")
	public String getAllElectronics(ModelMap mm,int dep){
		List<Post> posts=postrepo.getAllPostsByDepartment(dep);
		mm.addAttribute("posts",posts);
		return "/homepage.jsp";
	}
	
	@GetMapping("/homepage/industrial")
	public String getAllIndustrial(ModelMap mm,int dep){
		List<Post> posts=postrepo.getAllPostsByDepartment(dep);
		mm.addAttribute("posts",posts);
		return "/homepage.jsp";
	}
	
	@GetMapping("/homepage/chemical")
	public String getAllChemical(ModelMap mm,int dep){
		List<Post> posts=postrepo.getAllPostsByDepartment(dep);
		mm.addAttribute("posts",posts);
		return "/homepage.jsp";
	}
	
	@GetMapping("/homepage/computer")
	public String getAllComputer(ModelMap mm,int dep){
		List<Post> posts=postrepo.getAllPostsByDepartment(dep);
		mm.addAttribute("posts",posts);
		return "/homepage.jsp";
	}
	
	@GetMapping("/homepage/architecture")
	public String getAllArchitecture(ModelMap mm,int dep){
		List<Post> posts=postrepo.getAllPostsByDepartment(dep);
		mm.addAttribute("posts",posts);
		return "/homepage.jsp";
	}
	
	@GetMapping("/homepage/information_technology")
	public String getAllIT(ModelMap mm,int dep){
		List<Post> posts=postrepo.getAllPostsByDepartment(dep);
		mm.addAttribute("posts",posts);
		return "/homepage.jsp";
	}
	
	@GetMapping("/homepage/computer_science")
	public String getAllCS(ModelMap mm,int dep){
		List<Post> posts=postrepo.getAllPostsByDepartment(dep);
		mm.addAttribute("posts",posts);
		return "/homepage.jsp";
	}
	
	@GetMapping("/homepage/nursing")
	public String getAllNursing(ModelMap mm,int dep){
		List<Post> posts=postrepo.getAllPostsByDepartment(dep);
		mm.addAttribute("posts",posts);
		return "/homepage.jsp";
	}
	
	@GetMapping("/homepage/case")
	public String getAllCase(ModelMap mm,int dep){
		List<Post> posts=postrepo.getAllPostsByDepartment(dep);
		mm.addAttribute("posts",posts);
		return "/homepage.jsp";
	}
	
}
