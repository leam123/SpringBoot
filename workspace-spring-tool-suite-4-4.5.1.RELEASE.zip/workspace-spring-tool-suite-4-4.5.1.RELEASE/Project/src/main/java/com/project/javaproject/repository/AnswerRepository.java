package com.project.javaproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.javaproject.entity.Answer;

public interface AnswerRepository extends JpaRepository<Answer, Integer>{
}
